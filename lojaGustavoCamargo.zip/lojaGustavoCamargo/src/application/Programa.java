package application;

import java.util.Locale;
import java.util.Scanner;

import entities.Impressoras;
import entities.Monitores;
import entities.PlacaVideos;

public class Programa {

	public static void main(String[] args) {
		Locale.setDefault(Locale.US);
		Monitores monitor = new Monitores();
		Impressoras printers = new Impressoras();
		PlacaVideos placa = new PlacaVideos();

		Scanner sc = new Scanner(System.in);

		System.out.println("-------------------------------\n" + "Cadastro de produtos\n"
				+ "Escolha uma categoria para cadastrar\n" + "1 - Monitores\n" + "2 - Impressora\n"
				+ "3 - Placas de video");
		int categoria = sc.nextInt();

		sc.nextLine();
		switch (categoria) {
		case 1:
			System.out.println("Cadastre o nome da marca: ");
			String marcaMon = sc.nextLine();
			monitor.setMarcaMon(marcaMon);
			System.out.println("Cadastre o nome do monitor: ");
			String nomeMon = sc.nextLine();
			monitor.setNomeMon(nomeMon);
			System.out.println("Cadastre o preço do monitor: ");
			double precoMon = sc.nextDouble();
			monitor.setPrecoMon(precoMon);
			System.out.println("Cadastre a quantidade em estoque: ");
			int quantiMon = sc.nextInt();
			monitor.setQuantMon(quantiMon);
			
			System.out.println(monitor.monTotal());
			break;
		case 2:
			System.out.println("Cadastre o nome da marca: ");
			String printMarca = sc.nextLine();
			printers.setMarca(printMarca);

			System.out.println("Cadastre o nome da impressora: ");
			String printNome = sc.nextLine();
			printers.setNome(printNome);

			System.out.println("Cadastre o preço da impressora: ");
			double printPreco = sc.nextDouble();
			printers.setPreco(printPreco);

			System.out.println("Cadastre a quantidade das impressoras em estoque: ");
			int printQuant = sc.nextInt();
			printers.setQuant(printQuant);

			System.out.println("Cadastre o estoque de tinta atual");
			int printStock = sc.nextInt();
			printers.setStock(printStock);
			
			System.out.println(printers.impTotal());
			break;
		case 3:
			System.out.println("Cadastre o nome da marca: ");
			String marcaPlaca = sc.nextLine();
			placa.setMarca(marcaPlaca);
			System.out.println(placa.getMarca());

			System.out.println("Cadastre o nome da placa de video: ");
			String nomePlaca = sc.nextLine();
			placa.setNome(nomePlaca);

			System.out.println("Cadastre o preço do produto: ");
			double precoPlaca = sc.nextDouble();
			placa.setPreco(precoPlaca);

			System.out.println("Cadastre a quantidade desejada");
			int quantPlaca = sc.nextInt();
			placa.setQuant(quantPlaca);

			System.out.println(placa.placaTotal());
			break;
		default:
			System.out.println("Numero inválido");
			
			break;
		}

		sc.close();
	}

}