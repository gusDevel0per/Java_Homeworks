package entities;

public class Monitores {
	private String nomeMonitor;
	private String marcaMonitor;
	private double precoMonitor;
	private int quantMonitor;

	public String getNomeMon() {
		return nomeMonitor;
	}

	public void setNomeMon(String nomeMon) {
		this.nomeMonitor = nomeMon;
	}

	public String getMarcaMon() {
		return marcaMonitor;
	}

	public void setMarcaMon(String marcaMon) {
		this.marcaMonitor = marcaMon;
	}

	public double getPrecoMon() {
		return precoMonitor;
	}

	public void setPrecoMon(double precoMon) {
		this.precoMonitor = precoMon;
	}

	public int getQuantMon() {
		return quantMonitor;
	}

	public void setQuantMon(int quantiMon) {
		this.quantMonitor = quantiMon;
	}
	
	public String monTotal() {
		return "Nome da marca: " + marcaMonitor + "\tNome: " + nomeMonitor + "\nPreço: " + precoMonitor + "\tQuantidade: " + quantMonitor;
	}
}
