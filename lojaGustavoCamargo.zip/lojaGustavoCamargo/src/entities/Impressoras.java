package entities;

public class Impressoras {
	private String nome;
	private String marca;
	private int estoqueTinta;
	private int quantidade;
	private double preco;
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String printNome) {
		this.nome = printNome;
	}
	
	public String getMarca() {
		return marca;
	}
	
	public void setMarca(String printMarca) {
		this.marca = printMarca;
	}
	public int getStock() {
		return estoqueTinta;	
	}
	
	public void setStock(int printStock) {
		this.estoqueTinta = printStock;
	}
	
	public double getPreco() {
		return preco;
	}
	
	public void setPreco(Double printPreco) {
		this.preco = printPreco;
	}
	
	public int getQuant() {
		return quantidade;
	}
	
	public void setQuant(int printQuant) {
		this.quantidade = printQuant;
	}
	
	public String impTotal(){
		return "Nome da marca: " + marca + "\tNome: " + nome + "\nPreço: " + preco + "\tQuantidade: " + quantidade + "\nEstoque de tinta: " + estoqueTinta;
	}
	
}
