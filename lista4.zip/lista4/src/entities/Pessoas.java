package entities;

public class Pessoas {
	
	private String[] nome = new String[10];
	private int[] cpf = new int[10];
	private int[] matricula = new int [10];
	
	
	public String getNome(int i) {
		return nome[i];
	}
	public void setNome(String nome, int i) {
		this.nome[i] = nome;
	}
	public int getCpf(int i) {
		return cpf[i];
	}
	public void setCpf(int cpf, int i) {
		this.cpf[i] = cpf;
	}
	public int getMatricula(int i) {
		return matricula[i];
	}
	public void setMatricula(int matricula, int i) {
		this.matricula[i] = matricula;
	}

	
	public String toString(int i) {
		return "Pessoas [nome=" + nome[i] + ", cpf=" + cpf[i] + ", matricula=" + matricula[i] + "]";
	}
	
		
	
}
