package application;
import java.util.Scanner;

import application.Graduacao_GustavoCamargodaSilva;
import application.PosGraduacao_GustavoCamargodaSilva;
import entities.Pessoas;

public class Programa_GustavoCamargodaSilva {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Graduacao_GustavoCamargodaSilva g1 = new Graduacao_GustavoCamargodaSilva();
		PosGraduacao_GustavoCamargodaSilva g2 = new PosGraduacao_GustavoCamargodaSilva();
		
		String nome;
		String curso;
		int cpf;
		int matricula;
		
		
		
		for(int i = 0; i <10; i++) {
			System.out.println();
			System.out.println("--------------------------\n1 - Cadastro Graduação\n2 - Cadastro PosGraduação\n3 - Sair");
		
			int opcao = sc.nextInt();
			sc.nextLine();
			
			
			
			
			switch (opcao) {
			case 1:
				System.out.println("Insira o nome do aluno: ");
				nome = sc.nextLine();
				g1.setNome(nome, i);
				
				System.out.println("Insira o curso sendo cursado pelo aluno: ");
				curso = sc.nextLine();
				g1.setCursoGraduacao(curso, i);
				
				System.out.println("Insira o CPF do aluno: ");
				cpf = sc.nextInt();
				g1.setCpf(cpf, i);
				
				System.out.println("Insira a matricula do aluno: ");
				matricula = sc.nextInt();
				g1.setMatricula(matricula, i);
				
				
				
				break;
			case 2:
				System.out.println("Insira o nome do aluno: ");
				nome = sc.nextLine();
				g2.setNome(nome, i);
				
				System.out.println("Insira o curso sendo cursado pelo aluno: ");
				curso = sc.nextLine();
				g2.setCursoPosgraduacao(curso, i);
				
				System.out.println("Insira o CPF do aluno: ");
				cpf = sc.nextInt();
				g2.setCpf(cpf, i);
				
				System.out.println("Insira a matricula do aluno: ");
				matricula = sc.nextInt();
				g2.setMatricula(matricula, i);
				break;
			case 3:
				i = 10;
				break;
			default:
				System.err.println("Seleção inválida!");
				i--;
				break;
			}
		}
		
		System.out.println(g1.toString(1));
		
		sc.close();
	}

}
