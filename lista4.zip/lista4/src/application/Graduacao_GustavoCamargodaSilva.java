package application;

import java.util.Arrays;

import entities.Pessoas;

public class Graduacao_GustavoCamargodaSilva extends entities.Pessoas {
	private String[] cursoGraduacao = new String[10];
	
	public String getCursoGraduacao(int i) {
		return cursoGraduacao[i];
	}

	public void setCursoGraduacao(String cursoGraduacao, int i) {
		this.cursoGraduacao[i] = cursoGraduacao;
	}

	@Override
	public String toString(int i) {
		return "[Curso Graduacao: " + cursoGraduacao[i] + ", "
				+ super.toString(i);
	}

	

	
	

	
	
	
}
