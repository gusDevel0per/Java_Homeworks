package application;
import java.util.Arrays;

import entities.Pessoas;
public class PosGraduacao_GustavoCamargodaSilva extends entities.Pessoas{
	private String[] cursoPosgraduacao = new String[10];

	public String getCursoPosgraduacao(int i) {
		return cursoPosgraduacao[i];
	}

	public void setCursoPosgraduacao(String cursoPosgraduacao, int i) {
		this.cursoPosgraduacao[i] = cursoPosgraduacao;
	}

	
	public String toString(int i) {
		return "[Curso Posgraduacao: " + cursoPosgraduacao[i]
				+ ", " + super.toString(i);
	}


	
}
